



lst = [
    ['Абрикос', 10],
    ['Помидор', 8],
    ['Банан', 18],
]


lst = sorted(lst, key=lambda x: x[1])

print(lst)
