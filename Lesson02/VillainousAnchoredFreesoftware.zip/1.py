#set, dict, list





lst = [1, 'fff', 1.02, [1,3.2, 'f']]

lst.append(2)


print(lst)


#lst = [139913645143040, 13991364514312234, 1399136451234234, 13991364514234234,13991364514234234, 13991364514234234 ]



stroka = 'Hello'


lst[0] = 123
stroka[0] = 'J'

print(stroka[0])
print(lst[0])