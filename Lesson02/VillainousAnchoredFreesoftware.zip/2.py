from sys import getsizeof


print(getsizeof([])) # 56

print(getsizeof([1])) # 64 = 56 + 8

print(getsizeof([1,2])) # 72 = 56 + 8 + 8


print(getsizeof(1)) # 28

print(getsizeof([0,1,2,3,4,5,6,7,8,9])) # 136

# 136 = 56 + 8*10
# 28 * 10 = 280

# 280 + 136 = 416


# 4*10 = 40


print(getsizeof([1,1,1,1,1,1,1,1,1,1]))

#136+28